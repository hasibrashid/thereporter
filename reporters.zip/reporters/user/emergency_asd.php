<?php

	include('connect.php');



		$sql_emg = "INSERT INTO `emergency`( `u_id`, `latitude`, `longitude`) VALUES ('".$_POST['uid']."','".$_POST['q']."','".$_POST['ans']."')";

		$conn->query($sql_emg);
		musqli_close();
		$conn = null;
	
//'".$_POST['uid']."','".$_POST['q']."','".$_POST['ans']."'
?>
