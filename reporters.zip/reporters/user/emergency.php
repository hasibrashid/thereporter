<!--=======================Session==========================-->
<?php


	session_start();
	
	if(!empty($_SESSION['type']=='user')){
		//echo "hello";
	}else{
		header('location: ../index.php');
	}

	$u_email = $_SESSION['email'];
	include("../connect.php"); 
    
    $query = "SELECT * FROM `users` WHERE email = '$u_email'";
    $result = $conn->query($query);
    $row = mysqli_fetch_assoc($result);
    $id = $row['uid'];
    $name = $row['name'];
    
    $email = $row['email'];
?>
<html lang="en" class="no-js">
<head>
	<title>The Reporter</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='http://fonts.googleapis.com/css?family=Montserrat:300,400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,400italic' rel='stylesheet' type='text/css'>
	
	
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen">	
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen">

	<link rel="stylesheet" href="css/dropdown.css">

</head>
<body>

	<!-- Container -->
	<div id="container">
		<!-- Header
		    ================================================== -->
		<header class="clearfix">
			<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
				<div class="top-line">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								<ul class="info-list">
									<li>
										<i class="fa fa-globe"></i>
										Language: <span>English</span>
									</li>
									<li>
										<i class="fa fa-phone"></i>
										Call us:
										<span>02 89012-8</span>
									</li>
									<!--<li>
										<i class="fa fa-clock-o"></i>
										working time:
										<span>08:00 - 19:00</span>
									</li> -->
								</ul>
							</div>	
							<div class="col-md-4">
								<ul class="social-icons">
									<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
									<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a class="dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
								</ul>
							</div>	
						</div>
					</div>
				</div>
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<div class="dropdown">
									<img src="images/avatar.png" class="userimg" >
	  								<div class="dropdown-content">
									  	<a href="userprofile.php">profile</a>
									    <a href="../logout.php">Logout</a>
									    <a href="#">settings</a>
									    
									</div>
							</div>
						<a class="navbar-brand" href="index.php">The Reporter</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li><a class="active" href="index.php">Home</a></li>
							
							<li><a href="#">About</a></li>
							<li><a href="blog.php">What's New</a></li>
							
							
							<li><a href="#">PCR</a></li>
							<li class="search"><a href="#" class="open-search"><i class="fa fa-search"></i></a>
								<form class="form-search">
									<input type="search" placeholder="Search:"/>
									<button type="submit">
										<i class="fa fa-search"></i>
									</button>
								</form>
							</li>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>
		</header>
		<!-- End Header -->

		<!-- page-banner-section 
			================================================== -->
		<section class="page-banner-section">
			<div class="container">
				<h1>Emergency</h1>
			</div>
		</section>
		<!-- End page-banner section -->

		<!-- blog section 
			================================================== -->
		<section class="blog-section">
			<div class="container">
				<div class="row">
				<?php
					include 'connect.php';

					$sql_not_d = "SELECT * FROM `emergency` join users WHERE emergency.u_id = '".$_GET['uid']."'";
		    		$res_not_d = $conn->query($sql_not_d);
		    		//$row_not_d = mysqli_fetch_assoc($res_not_d);
		    		$row_not_d = mysqli_fetch_assoc($res_not_d);
		    		echo '<h2> '.$row_not_d['name'].' is under attack</h2>';

		    		//echo '<h2> Lat: '.$row_not_d['latitude'].' </h2>';
		    		//echo '<h2> Long: '.$row_not_d['longitude'].' </h2>';





				?>
				<div id="mapholder"></div>

				</div>	
			</div>
		</section>
		<!-- End blog section -->

		<!-- subcribe-section 
			================================================== -->
		<!--
		<section id="subcribe-section">
			<div class="container">
				<div class="title-section white">
					<h1>Connect with us</h1>
				</div>
				<form class="subscribe">
					<!--<input type="text" name="name-subs" id="name-subs" placeholder="name"/>
					<input type="text" name="email-subs" id="email-subs" placeholder="your email address"/>-->
					<!--<input type="submit" id="submit-subscribe" value="sign in"/>
					<input type="submit" id="submit-subscribe" value="sign up"/>
				</form>
			
			</div>
		</section>-->

		<!-- End subscribe section -->

		<!-- footer 
			================================================== -->
		<footer>
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="contact-info">
							<h2><i class="fa fa-location-arrow"></i> Our Address</h2>
							<p>HAS 8/a Dhanmondi ,</br> Dhaka, Bangladesh</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="contact-info">
							<h2><i class="fa fa-envelope-o"></i> Contact Us</h2>
							<p>02 54374564 <br> info@has.com</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="contact-info">
							<h2><i class="fa fa-clock-o"></i> Office hours</h2>
							<p>Monday to Friday: 8:00 - 18:00 <br> Saturday, Sunday: 9:00 - 14:00</p>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- End footer -->

	</div>
	<!-- End Container -->
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.migrate.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.imagesloaded.min.js"></script>
	<script type="text/javascript" src="js/retina-1.1.0.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
<script src="https://maps.google.com/maps/api/js?key=AIzaSyA1ld3MLQYgFrQydHo_izd74sFKyR-uOac"></script>

	<script>
		
		    var lat = <?php echo $row_not_d['latitude']; ?>;
		    var lon = <?php echo $row_not_d['longitude']; ?>;
		    //alert(lat,lon);
		    var latlon = new google.maps.LatLng(lat, lon)
		    var mapholder = document.getElementById('mapholder')
		    mapholder.style.height = '250px';
		    mapholder.style.width = '800px';

		    var myOptions = {
		    center:latlon,zoom:14,
		    mapTypeId:google.maps.MapTypeId.ROADMAP,
		    mapTypeControl:false,
		    navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}
		    }
		    
		    var map = new google.maps.Map(document.getElementById("mapholder"), myOptions);
		    var marker = new google.maps.Marker({position:latlon,map:map,title:"You are here!"});
		
		</script>

</body>
</html>