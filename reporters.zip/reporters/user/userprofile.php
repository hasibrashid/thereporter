<!--=======================Session==========================-->
<?php


	session_start();
	
	if(!empty($_SESSION['type']=='user')){
		//echo "hello";
	}else{
		header('location: ../index.php');
	}

	$u_email = $_SESSION['email'];
	include("../connect.php"); 
    
    $query = "SELECT * FROM `users` WHERE email = '$u_email'";
    $result = $conn->query($query);
    $row = mysqli_fetch_assoc($result);
    $id = $row['uid'];
    $name = $row['name'];
    
    $email = $row['email'];
?>

<html lang="en" class="no-js">
<head>
	<title>The Reporter</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='http://fonts.googleapis.com/css?family=Montserrat:300,400,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,400italic' rel='stylesheet' type='text/css'>
	
	
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" media="screen">	
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen">

	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
	<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


	<link rel="stylesheet" href="css/button.css">
	<link rel="stylesheet" href="css/profile.css">
	<link rel="stylesheet" href="css/w3login.css">
	<link rel="stylesheet" href="css/w3signup.css">

</head>
<body>

	<!-- Container -->
	<div id="container">
		<!-- Header
		    ================================================== -->
		<header class="clearfix">
			<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
				<div class="top-line">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								<ul class="info-list">
									<li>
										<i class="fa fa-globe"></i>
										Language: <span>English</span>
									</li>
									<li>
										<i class="fa fa-phone"></i>
										Call us:
										<span>02 89012-8</span>
									</li>
									<!--<li>
										<i class="fa fa-clock-o"></i>
										working time:
										<span>08:00 - 19:00</span>
									</li> -->
								</ul>
							</div>	
							<div class="col-md-4">
								<ul class="social-icons">
									<li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
									<li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a class="dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
								</ul>
							</div>	
						</div>
					</div>
				</div>
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.php">The Reporter</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li><a class="active" href="index.php">Home</a></li>
							
							<li><a href="#">About</a></li>
							<li><a href="blog.php">What's New</a></li>
							
							
							<li><a href="#">PCR</a></li>
							<li class="search"><a href="#" class="open-search"><i class="fa fa-search"></i></a>
								<form class="form-search">
									<input type="search" placeholder="Search:"/>
									<button type="submit">
										<i class="fa fa-search"></i>
									</button>
								</form>
							</li>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>
		</header>
		<!-- End Header -->

		<!-- page-banner-section 
			================================================== -->
		<section class="page-banner-section">
			<div class="container">
				<h1>Profile</h1>
			</div>
		</section>
		<!-- End page-banner section -->

		<!-- blog section 
			================================================== -->
		


		
			<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
					  <!-- The Grid -->
					  <div class="w3-row">
					    <!-- Left Column -->
					    <div class="w3-col m3">
					      <!-- Profile -->
					      <div class="w3-card-2 w3-round w3-white">
					      			<a href="userprofile.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-grey" title="News"><i class="fa fa-home"></i></a>
								<div class="w3-dropdown-hover w3-hide-small">	  
									<a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-grey" title="Messages"><i class="fa fa-envelope"></i></a>
									<div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
								      <a href="#" class="w3-bar-item w3-button">Message From Admin</a>
								      <a href="#" class="w3-bar-item w3-button">Welcome to the Reporters</a>
								      
								    </div>
								</div>
						  		<div class="w3-dropdown-hover w3-hide-small">
								    <button class="w3-button w3-padding-large" title="Notifications"><i class="fa fa-bell"></i><span class="w3-badge w3-right w3-small w3-green">
								    	<?php

								    		include('connect.php');
								    		$sql_not = "SELECT count(id) as noti_count FROM `emergency` WHERE u_id != '$id'";
								    		$res_not = $conn->query($sql_not);
								    		$row_not = mysqli_fetch_assoc($res_not);
								    		echo $row_not['noti_count'];

								    	?>
								    </span></button>     
								    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
								      <!-- <a href="emergency.php" class="w3-bar-item w3-button">Rony is under attack</a>
								      <a href="#" class="w3-bar-item w3-button">Hasib post an article</a>
								      <a href="#" class="w3-bar-item w3-button">Antara is under attack</a> -->

								      <?php

								    		include('connect.php');
								    		$sql_not_d = "SELECT * FROM `emergency` join users WHERE u_id != '$id' and emergency.u_id = users.uid";
								    		$res_not_d = $conn->query($sql_not_d);
								    		//$row_not_d = mysqli_fetch_assoc($res_not_d);
								    		while($row_not_d = mysqli_fetch_assoc($res_not_d))
								    		{

								    			echo '<a href="emergency.php?uid='.$row_not_d['u_id'].' class="w3-bar-item w3-button">'.$row_not_d['name'].' is under attack</a><br>';
								    		}

								    	?>
								    </div>
								    
						  		</div>
						  		<div class="w3-dropdown-hover w3-hide-small">
						  				<a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-grey" title="Account Settings"><i class="fa fa-user"></i></a>
						  				<div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
										      <a href="#" class="w3-bar-item w3-button">Settings</a>
										      <a href="../logout.php" class="w3-bar-item w3-button">Logout</a>
										      
								    	</div>


				  				</div>
					      </div>
					      <br>
					      <div class="w3-card-2 w3-round w3-white">
					        <div class="w3-container">
					        <br>
					        

					         <h4 class="w3-center"></h4>
					         <p class="w3-center"><img src="images/avatar.png" class="w3-circle" style="height:106px;width:106px" alt="Avatar"></p>
					         <hr>
					         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i><?php echo $name; ?></p>
					         <p><i class="fa fa-envelope fa-fw w3-margin-right w3-text-theme"></i><?php echo $email; ?></p>
					         <p><i class="fa fa-phone fa-fw w3-margin-right w3-text-theme"></i> 01674519173</p>
					         
							  
					        </div>
					      </div>
					      <br>
					      <!-- <form method="post" action=""> -->
					      <!-- Accordion -->
					      
					        
					         		<!-- popup Modal-->	

					         		<input type="hidden" id="lat_hid" name="emg_lat_hid"> <input type="hidden" id="long_hid" name="emg_long_hid">

					         			<button  class="emergency buttonhelp" name="emg_submitPost" href="javascript:void(0)" class="map buttonmap" name="submitPost" onclick="document.getElementById('subscribe').style.display='block'; getLocationEmg()"> EMERGENCY</button>

					        <!-- </form> -->
					         			<button href="javascript:void(0)" class="map buttonmap" name="submitPost" onclick="document.getElementById('getmap').style.display='block'"><i class="fa fa-globe"></i> &nbsp; Area Map</button>
					         			
					         			<button href="javascript:void(0)" class="map buttonmap" id="my_location" onclick="document.getElementById('locate').style.display='block'; getLocation()" ><i class="fa fa-location-arrow"></i> &nbsp;location</button>
					            
					     
					      <br>
					      <br>

					      
					      <!-- Interests --> 
					      
					      <br>
					      
					      <!-- Alert Box -->
					      
					    
					    <!-- End Left Column -->
					    </div>
					    
					    <!-- Middle Column -->



			    <div class="w3-col m7">
								<div class="w3-main w3-white" style="margin-left:260px">
							    		<div id="subscribe" class="w3-modal" style="display: none;">
									  <div class="mymodal w3-animate-zoom w3-padding-large">
									    <div class="w3-container w3-white w3-center">
									      <i id="closeicon" onclick="document.getElementById('subscribe').style.display='none'" class="fa fa-remove w3-button w3-xlarge w3-right w3-transparent"></i>
									      <h2 class="w3-wide" style="text-align: center;">SUCCESSFULL </h2>
									       <input type="hidden" id="lat" name="emg_lat" readonly>  <input type="hidden" id="long" name="emg_long" readonly>
									      <h3>Your request has been sent successfully.</h3>
									      
									    </div>
									  </div>
									</div>
								</div>

								<div class="w3-main w3-white" style="margin-left:260px">
							    		<div id="getmap" class="w3-modal" style="display: none;">
									  <div class="mymodal w3-animate-zoom w3-padding-large">
									    <div class="w3-container w3-white w3-center">
									      <i onclick="document.getElementById('getmap').style.display='none'" class="fa fa-remove w3-button w3-xlarge w3-right w3-transparent"></i>
									       <img src="images/map.jpg" style="width:100%"  class="w3-margin-bottom">
									      
									    </div>
									  </div>
									</div>
								</div>

								<div class="w3-main w3-white" style="margin-left:260px">
							    		<div id="locate" class="w3-modal" style="display: none;">
											    <div class="mymodal w3-animate-zoom w3-padding-large">
												    <div class="w3-container w3-white w3-center">
													      <i onclick="document.getElementById('locate').style.display='none'" class="fa fa-remove w3-button w3-xlarge w3-right w3-transparent"></i>
													      <h2 class="w3-wide" style="text-align: center;">Location </h2>
													      <!-- <h3>Your current location is Dhnmondi 15.</h3> -->
													      <div id="mapholder"></div>
												    </div>
											    </div>
										</div>
								</div>
									
								


					    
				    <div class="w3-row-padding">
					        <div class="w3-col m12">
					          <div class="w3-card-2 w3-round w3-white">
					            	<div class="profile">
							            <div class="post-padding">
							            <form id="blogpost" action="" method="post" enctype="multipart/form-data">
							              <h4 class="post-opacity">Post a Crime</h4>
									              <!-- <form id="blogpost" action="" method="post"> -->

									              		<div class="field">
									                         <textarea  name="postBody" rows="6" cols="65"></textarea>
									                    </div>
									                    
									              <!-- </form> -->
									                <select id="catagory" name="ctg">
													      <option value="catagory">Catagory</option>
													      <option value="murder">Murder</option>
													      <option value="rape">Rape</option>
													      <option value="scam">Scam</option>
												    </select>
												   
												    <select id="catagory" name="place">
													      <option value="place">Place</option>
													      <option value="dhanmondi">Dhanmondi</option>
													      <option value="uttara">Uttara</option>
													      <option value="banani">Banani</option>
												    </select>
									              <!-- <input type="file" class="buttonCustom buttonCustom2" name="image" /> -->
												  <input id="aa" type="file" name="image" >
												  <button type="submit" class="buttonpost button2" name="submitPost">Post</button>
												  
												
												<!--<div class="fileUpload btn btn-primary">
												    <span>Upload</span>
												    <input type="file" class="upload" />
												</div>-->
												</form>
										</div>
			          				</div>
					          </div>
					        </div>
			     	</div>

			     	<?php

				include ('connect.php');

				if(isset($_POST['submitPost'])){

					// if(getimagesize($_FILES['image']['tmp_name']) == false){
					// 	$image = null;
					// }
					// else{
					$image = addslashes($_FILES['image']['tmp_name']);
			          //$image = addslashes($_FILES['image']['name']);
			        $image = file_get_contents($image);
			        $image = base64_encode($image);
			    //}
			    $timestamp = time()+3600*6;
			      $dt = gmdate("Y/m/d H:i:s",$timestamp);


				$sql = "INSERT INTO `post`(`u_id`, `body`, `category`, `area`, `image`, `time`) VALUES ('$id','".$_POST['postBody']."','".$_POST['ctg']."', '".$_POST['place']."', '$image', '$dt')";

				$res = $conn->query($sql);
				mysqli_close($conn);
				if(!$res) {
	                echo "<script>
	                        alert('Not uploaded.');
	                        window.location.href='userprofile.php';
	                    </script>";
            		}		
		            else{
		                echo "<script>
		                        alert('Post uploaded.');
		                        window.location.href='userprofile.php';
		                    </script>";    
		            }
		   			$conn = null;
		   		}

		   		
			    include('connect.php');

	   			if(isset($_POST['Btn'])){
	   				// echo $_POST['com'];
	   				//echo $_POST['commentBody'];

	   				if($_POST['commentBody'] != ""){

	   					$timestamp = time()+3600*6;
			      		$dt = gmdate("Y/m/d H:i:s",$timestamp);


						$sqlComment = "INSERT INTO `comments`(`post_id`, `u_id`, `body`, `time`) VALUES ('".$_POST['commId']."', '$id','".$_POST['commentBody']."' , '$dt')";

				$resC = $conn->query($sqlComment);
				mysqli_close($conn);
				$conn = null;
	   				}

	   			}

	   			
	   			

	   			include('connect.php');
		   		$q = "SELECT * FROM `post` WHERE u_id = '$id' order by time DESC ";
    			$re = $conn->query($q);
    			$r = mysqli_fetch_assoc($re);
				
    			while($r != null){
        		echo '
        			<div class="post-profile">

			        <img src="images/avatar.png" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px"><span class="post-time">'.$r['time'].'</span>
			        <div class="username">'.$name.'</div><br>
			        
			        <p>'.$r['body'].'</p>
			        <br>
			          
			            <div clas="img-bottom">
			              <img src="data:image;base64,' .$r['image'].'" style="width:100%"  class="w3-margin-bottom"  alt="" > 
			            </div>
			            
			        
			        <br>
			       <div class="myform">
			        <form action = "" method = "post">
				        <textarea  rows="6" cols="70" name= "commentBody" autocomplete="off"> </textarea><br>
				        <button type="submit" class="button button1" name= "likeBtn">Like</button>
				        <button type="submit" class="button button2" name="Btn">Comment</button>
				        
				        <input type= "hidden" name="postId" value="'.$id.'" >
				        <input type= "hidden" name="commId" value="'.$r['id'].'" >

				       
			        </form>
			        </div>
			        ';
			        
	   				include('connect.php');

			        $sqlCom = "SELECT * FROM `comments`, users WHERE comments.u_id = users.uid and post_id = '".$r['id']."' order by time DESC ";
			        $ressC= $conn->query($sqlCom);
			        $rowC = mysqli_fetch_assoc($ressC);
			        while($rowC != null){
			        echo '
			       
			        <div >
			          <img src="images/avatar.png" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px"><h4>'.$rowC['name'].' </h4><small>'.$rowC['time'].'</small>
			          <p>'.$rowC['body'].'</p>
			          
			        </div>';
			        $rowC = mysqli_fetch_assoc($ressC);
			        }

     			 
     			echo '</div>';
     			 $r = mysqli_fetch_assoc($re);
     			}

 			?>
 		
					     <!--
					      <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
					        <img src="images/avatar.png" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
					        <span class="w3-right w3-opacity">1 min</span>
					        <h4>Suvo</h4><br>
					        <hr class="w3-clear">
					        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					          <div class="w3-row-padding" style="margin:0 -16px">
					            
					              <img src="images/crime1.jpg" style="width:100%"  class="w3-margin-bottom">
					            
					            
					        </div>
					        <button type="submit" class="button button1" name="likeBtn"><i class="fa fa-thumbs-up"></i> &nbsp;Like</button>
					        <button type="submit" class="button button2" name="Btn">Comment</button>
					        
					      </div>
					      
					      <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
					        <img src="images/avatar.png" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
					        <span class="w3-right w3-opacity">16 min</span>
					        <h4>Suvo</h4><br>
					        <hr class="w3-clear">
					        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					        <button type="submit" class="button button1" name="likeBtn"><i class="fa fa-thumbs-up"></i> &nbsp;Like</button>
					        <button type="submit" class="button button2" name="Btn">Comment</button>
					      </div>  

					      <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
					        <img src="images/avatar.png" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
					        <span class="w3-right w3-opacity">32 min</span>
					        <h4>Suvo</h4><br>
					        <hr class="w3-clear">
					        <p>Have you seen this?</p>
					        <img src="images/crime2.jpg" style="width:100%" class="w3-margin-bottom">
					        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					        <button type="submit" class="button button1" name="likeBtn"><i class="fa fa-thumbs-up"></i> &nbsp;Like</button>
					        <button type="submit" class="button button2" name="Btn">Comment</button>
					        <br>
					      </div> 
					      -->
					      
					    <!-- End Middle Column -->
			    </div>
					    
					    <!-- Right Column -->
					    <div class="w3-col m2">
					      <div class="w3-card-2 w3-round w3-white w3-center">
					        <div class="w3-container">
					        <br>
					          <p>Upcoming Events:</p>
					          <img src="images/crime3.jpg"  style="width:100%;">
					          <br>
					          <br>
					          <p><strong>Seminar</strong></p>
					          <p>Friday 15:00</p>
					          <p><button class="w3-button w3-block w3-theme-l4">Info</button></p>
					        </div>
					      </div>
					      <br>
					      
					      
					      
					      
					      <div class="w3-card-2 w3-round w3-white w3-padding-16 w3-center">
					        <p>ADS</p>
					      </div>
					      <br>
					      
					      <div class="w3-card-2 w3-round w3-white w3-padding-32 w3-center">
					        <p><i class="fa fa-bug w3-xxlarge"></i></p>
					      </div>
					      
					    <!-- End Right Column -->
					    </div>
					    
					  <!-- End Grid -->
					  </div>
					  
					<!-- End Page Container -->
					</div>
					<br>
					<br>
		
		<!-- End blog section -->

		<!-- subcribe-section 
			================================================== -->
		<!--
		<section id="subcribe-section">
			<div class="container">
				<div class="title-section white">
					<h1>Connect with us</h1>
				</div>
				
					<input type="submit" id="submit-subscribe" value="sign in"/>
					<input type="submit" id="submit-subscribe" value="sign up"/>
				</form>
				
			</div>
		</section>
		-->

		<!-- End subscribe section -->

		<!-- footer 
			================================================== -->
		<footer>
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="contact-info">
							<h2><i class="fa fa-location-arrow"></i> Our Address</h2>
							<p>HAS 8/a Dhanmondi ,</br> Dhaka, Bangladesh</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="contact-info">
							<h2><i class="fa fa-envelope-o"></i> Contact Us</h2>
							<p>02 54374564 <br> info@has.com</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="contact-info">
							<h2><i class="fa fa-clock-o"></i> Office hours</h2>
							<p>Monday to Friday: 8:00 - 18:00 <br> Saturday, Sunday: 9:00 - 14:00</p>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- End footer -->

	</div>
	<!-- End Container -->
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.migrate.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.imagesloaded.min.js"></script>
	<script type="text/javascript" src="js/retina-1.1.0.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<script src="https://maps.google.com/maps/api/js?key=AIzaSyA1ld3MLQYgFrQydHo_izd74sFKyR-uOac"></script>
	<script>
		var x = document.getElementById("my_location");

		function getLocation() {
		    if (navigator.geolocation) {
		        navigator.geolocation.getCurrentPosition(showPosition, showError);
		    } else {
		        x.innerHTML = "Geolocation is not supported by this browser.";
		    }
		}

		function showPosition(position) {
		    var lat = position.coords.latitude;
		    var lon = position.coords.longitude;
		    var latlon = new google.maps.LatLng(lat, lon)
		    var mapholder = document.getElementById('mapholder')
		    mapholder.style.height = '250px';
		    mapholder.style.width = '800px';

		    var myOptions = {
		    center:latlon,zoom:14,
		    mapTypeId:google.maps.MapTypeId.ROADMAP,
		    mapTypeControl:false,
		    navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}
		    }
		    
		    var map = new google.maps.Map(document.getElementById("mapholder"), myOptions);
		    var marker = new google.maps.Marker({position:latlon,map:map,title:"You are here!"});
		}
		//To use this code on your website, get a free API key from Google.
		//Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp

		function showError(error) {
		    switch(error.code) {
		        case error.PERMISSION_DENIED:
		            x.innerHTML = "User denied the request for Geolocation."
		            break;
		        case error.POSITION_UNAVAILABLE:
		            x.innerHTML = "Location information is unavailable."
		            break;
		        case error.TIMEOUT:
		            x.innerHTML = "The request to get user location timed out."
		            break;
		        case error.UNKNOWN_ERROR:
		            x.innerHTML = "An unknown error occurred."
		            break;
		    }
		}
		</script>


		<script>
			var x = document.getElementById("demo");

			function getLocationEmg() {
			    if (navigator.geolocation) {
			        navigator.geolocation.getCurrentPosition(showPositionEmg);
			    } else { 
			        x.innerHTML = "Geolocation is not supported by this browser.";
			    }
			}

			function showPositionEmg(position) {
			    document.getElementById("lat").value = position.coords.latitude;
			    document.getElementById("long").value = position.coords.longitude;
			    document.getElementById("lat_hid").value = position.coords.latitude;
			    document.getElementById("long_hid").value = position.coords.longitude;
			    //alert("hello");
				        // xmlhttp.open("GET","emergency_asd.php?q="+str"&w="+str2,true);
				        // xmlhttp.send();
			}
			</script>

			<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
			  <script type="text/javascript">     
			  $('#closeicon').on('click',function(){ 
				  
				  		var lat = document.getElementById("lat").value;
				  		var long = document.getElementById("long").value;
					  var urlString ="q="+lat+"&ans="+long+"&uid="+<?php echo $id; ?>;

					  $.ajax
					  ({
					  url: "emergency_asd.php",
					  type : "POST",
					  cache : false,
					  data : urlString,
					  success: function(response)
					  {
					  //alert(response);
					  }
					  });


				  
				});
			  </script>
</body>
</html>